package com.example.secondscreentv;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageFormat;
import android.graphics.Point;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Surface;
import android.view.SurfaceView;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.Date;

public class Screenshot extends Activity {

    private MediaProjectionManager mediaProjectionManager;
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private Display mDisplay;
    private int mWidth;
    private int mHeight;
    private int mDensity;
    private static int IMAGES_PRODUCED;
    private String ip;
    private String filePath;

    private class ImageAvailableListener implements ImageReader.OnImageAvailableListener {
        @Override
        public void onImageAvailable(ImageReader reader) {
            Image image = null;
            FileOutputStream fos = null;
            Bitmap bitmap = null;

            try {
                image = reader.acquireLatestImage();
                if (image != null && IMAGES_PRODUCED < 1) {
                    Image.Plane[] planes = image.getPlanes();
                    ByteBuffer buffer = planes[0].getBuffer();
                    int pixelStride = planes[0].getPixelStride();
                    int rowStride = planes[0].getRowStride();
                    int rowPadding = rowStride - pixelStride * mWidth;

                    // create bitmap
                    bitmap = Bitmap.createBitmap(mWidth + rowPadding / pixelStride, mHeight, Bitmap.Config.ARGB_8888);
                    bitmap.copyPixelsFromBuffer(buffer);

                    Date now = new Date();
                    android.text.format.DateFormat.format("yyyy-MM-dd_hh:mm:ss", now);
                    filePath = getExternalFilesDir(Environment.DIRECTORY_PICTURES).toString() + "/" + now + ".jpg";

                    // write bitmap to a file
                    fos = new FileOutputStream(filePath);
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);

                    IMAGES_PRODUCED++;
                    Log.e("Screenshot", "captured image: " + IMAGES_PRODUCED);

                    new Thread(new Client()).start();
                }

            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (fos != null) {
                    try {
                        fos.close();
                    } catch (IOException ioe) {
                        ioe.printStackTrace();
                    }
                }

                if (bitmap != null) {
                    bitmap.recycle();
                }

                if (image != null) {
                    image.close();
                }
            }
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        IMAGES_PRODUCED = 0;
        ip = getIntent().getStringExtra("ip");
        mediaProjectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mediaProjectionManager.createScreenCaptureIntent(), 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == Activity.RESULT_OK) {
                DisplayMetrics metrics = getResources().getDisplayMetrics();
                mDensity = metrics.densityDpi;
                mDisplay = getWindowManager().getDefaultDisplay();
                mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, data);
                createVirtualDisplay();

                //this.finish();
            }
        }

    }

    private void createVirtualDisplay() {
        Point size = new Point();
        mDisplay.getSize(size);
        mWidth = size.x;
        mHeight = size.y;

        imageReader = ImageReader.newInstance(mWidth, mHeight, 1 , 2);

        virtualDisplay = mediaProjection.createVirtualDisplay("test",
                mWidth, mHeight, mDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(), null /*Callbacks*/, null /*Handler*/);

        imageReader.setOnImageAvailableListener(new ImageAvailableListener(), null);
    }

    class Client implements Runnable{

        @Override
        public void run() {
            try{
                Socket socket = new Socket(ip, 8888);
                OutputStream outputStream = socket.getOutputStream();
                FileInputStream inputStream = new FileInputStream(filePath);
                byte[] buffer = new byte[1024];
                int read = 0;

                read = inputStream.read(buffer);
                while (read > 0){
                    outputStream.write(buffer, 0, buffer.length);
                    read = inputStream.read(buffer);
                }
                inputStream.close();
                outputStream.close();

            } catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}
