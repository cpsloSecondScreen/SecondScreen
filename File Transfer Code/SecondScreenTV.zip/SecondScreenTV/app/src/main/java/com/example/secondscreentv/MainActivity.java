package com.example.secondscreentv;


import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.IBinder;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.Toast;

import com.amazon.whisperplay.fling.media.service.CustomMediaPlayer.StatusListener;
import com.amazon.whisperplay.fling.media.service.MediaPlayerStatus;

import com.amazon.whisperplay.fling.media.service.MediaPlayerStatus.MediaState;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    Boolean bound;
    ServiceControl serviceControl;

    StatusListener mStatusListener = new StatusListener() {
        @Override
        public void onStatusChange(MediaPlayerStatus mediaPlayerStatus, long l) {
            MediaState state = mediaPlayerStatus.getState();
            if(state == MediaState.Error ){
                Log.i(TAG, "status: Error");
            }
        }
    };

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            bound = true;
            serviceControl = (ServiceControl) service;
            serviceControl.addStatusListener(mStatusListener);
            serviceControl.setContext(getApplicationContext());
            serviceControl.setActivity(getParent());
            Toast.makeText(getApplicationContext(), "bound to: " + name.toString(), Toast.LENGTH_LONG).show();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            bound = false;
            serviceControl = null;
            Toast.makeText(getApplicationContext(), "unbound", Toast.LENGTH_LONG).show();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //tvPlayerService = new TVPlayerService();
        //player = (TVPlayer) tvPlayerService.createServiceImplementation();
        Intent serviceintent = new Intent(this, TVPlayerService.class);
        bindService(serviceintent, serviceConnection, Context.BIND_AUTO_CREATE);

    }

    @Override
    protected void onDestroy() {
        unbindService(serviceConnection);
        serviceControl = null;
        super.onDestroy();
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if(serviceControl == null){
            return false;
        }
        try{
            switch(keyCode){
                case KeyEvent.KEYCODE_DPAD_CENTER:{
                    serviceControl.sendCommand("screenshot");
                    break;
                }
                case KeyEvent.KEYCODE_0:{
                    break;
                }
                default:{
                    Toast.makeText(getApplicationContext(), "code = " + keyCode, Toast.LENGTH_LONG).show();
                    break;
                }
            }

        } catch (Exception e){
            e.printStackTrace();
        }
        return  false;
    }
}
