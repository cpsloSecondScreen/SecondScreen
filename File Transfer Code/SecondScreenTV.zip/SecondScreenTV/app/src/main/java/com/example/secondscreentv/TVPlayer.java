package com.example.secondscreentv;

import android.app.Activity;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.os.Handler;
import android.widget.RelativeLayout;
import android.widget.Toast;


import com.amazon.whisperplay.fling.media.service.CustomMediaPlayer;
import com.amazon.whisperplay.fling.media.service.MediaPlayerInfo;
import com.amazon.whisperplay.fling.media.service.MediaPlayerStatus;

import android.view.SurfaceControl;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static androidx.constraintlayout.widget.Constraints.TAG;
import static java.security.AccessController.getContext;


public class TVPlayer implements CustomMediaPlayer {

    private Context mContext;
    private Activity activityScreen;

    List<StatusListener> mListeners = new ArrayList<StatusListener>();
    Handler mHandler;


    private volatile MediaPlayerStatus.MediaState mState = MediaPlayerStatus.MediaState.NoSource;
    private volatile MediaPlayerStatus.MediaCondition mError = MediaPlayerStatus.MediaCondition.Good;

    public TVPlayer(Context context){
        mContext = context;
        mHandler = new Handler(context.getMainLooper());
    }

    public void setActivity(Activity activity){
        this.activityScreen = activity;
    }

    @Override
    public double getVolume() throws IOException {
        return 0;
    }

    @Override
    public void setVolume(double v) throws IOException {

    }

    @Override
    public boolean isMute() throws IOException {
        return false;
    }

    @Override
    public void setMute(boolean b) throws IOException {

    }

    @Override
    public long getPosition() throws IOException {
        return 0;
    }

    @Override
    public long getDuration() throws IOException {
        return 0;
    }

    @Override
    public MediaPlayerStatus getStatus() throws IOException {
        MediaPlayerStatus mediaPlayerStatus = new MediaPlayerStatus(mState, mError);
        return  mediaPlayerStatus;
    }

    @Override
    public boolean isMimeTypeSupported(String s) throws IOException {
        return false;
    }

    @Override
    public void pause() throws IOException {

    }

    @Override
    public void play() throws IOException {

    }

    @Override
    public void stop() throws IOException {

    }

    @Override
    public void seek(PlayerSeekMode playerSeekMode, long l) throws IOException {

    }

    @Override
    public void setMediaSource(String s, String s1, boolean b, boolean b1) throws IOException {

    }

    @Override
    public void setPlayerStyle(String s) {

    }

    @Override
    public void addStatusListener(StatusListener statusListener) {
        mListeners.add(statusListener);
    }

    @Override
    public void removeStatusListener(StatusListener statusListener) {
        mListeners.remove(statusListener);
    }

    @Override
    public void setPositionUpdateInterval(long l) throws IOException {

    }

    @Override
    public void sendCommand(String s) throws IOException {
        Log.i("TVPlayer", s);
        openMainActivity(s);

    }

    private void openMainActivity(String ip) {
        Intent intent = new Intent(mContext, Screenshot.class);
        intent.putExtra("ip", ip);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        mContext.startActivity(intent);
    }

    @Override
    public MediaPlayerInfo getMediaInfo() throws IOException {
        return null;
    }


}
