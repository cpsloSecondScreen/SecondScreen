package example;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.S3Event;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.event.S3EventNotification.S3EventNotificationRecord;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.rekognition.AmazonRekognition;
import com.amazonaws.services.rekognition.AmazonRekognitionClient;
import com.amazonaws.services.rekognition.model.DetectLabelsRequest;
import com.amazonaws.services.rekognition.model.DetectLabelsResult;
import com.amazonaws.services.rekognition.model.Image;
import com.amazonaws.services.rekognition.model.Label;
import com.amazonaws.services.rekognition.model.BoundingBox;
import com.amazonaws.services.rekognition.model.Instance;
import com.amazonaws.services.rekognition.model.S3Object;

public class LambdaFunctionHandler implements RequestHandler<S3Event, String> {

	// Initialize s3 and rekognition
    private AmazonS3 s3 = AmazonS3ClientBuilder.standard().build();
    AmazonRekognition rekognitionClient = AmazonRekognitionClient.builder().build();

    public LambdaFunctionHandler() {}

    // Test purpose only.
    LambdaFunctionHandler(AmazonS3 s3) {
        this.s3 = s3;
    }

    @Override
    public String handleRequest(S3Event s3event, Context context) {
        S3EventNotificationRecord record = s3event.getRecords().get(0);

		String srcBucket = record.getS3().getBucket().getName();

		// Object key may have spaces or unicode non-ASCII characters.
		String srcKey = record.getS3().getObject().getUrlDecodedKey();

		//String dstBucket = "secondscreendestbucket";
		String dstKey = "public/json/rekresults-" + srcKey.substring(14, (srcKey.length() - 4)) + ".json";
		String dstKey2 = "fullresults-" + srcKey.substring(0, (srcKey.length() - 4)) + ".json";
		String labelNames = "{\n\"labels\": [";
		
		// perform detectlabels call on srcBucket
      Image imageToTag = new Image().withS3Object(new S3Object().withName(srcKey).withBucket(srcBucket));
        
		DetectLabelsRequest request = new DetectLabelsRequest()
                .withImage(imageToTag)
                .withMaxLabels(50)
                .withMinConfidence(74F);
		try {
            // call detect labels
            DetectLabelsResult result = rekognitionClient.detectLabels(request);
            List<Label> labels = result.getLabels();
                    
            if (labels.isEmpty()) {
                System.out.println("No label is recognized!");
            } else {
                System.out.println("Detected labels for " + imageToTag.getS3Object().getName());
            }
            // append labels with bounding box
            for (Label label : labels) {
                List<Instance> instances = label.getInstances(); 
                if (!instances.isEmpty()){
                    for (Instance i : instances){
                        BoundingBox box = i.getBoundingBox();
                        labelNames += ("{\"" + label.getName() + "\": ");
                        labelNames += ("{\"Width\": \"" + box.getWidth() + "\",");
                        labelNames += ("\"Height\": \"" + box.getHeight() + "\",");
                        labelNames += ("\"Left\": \"" + box.getLeft() + "\",");
                        labelNames += ("\"Top\": \"" + box.getTop() + "\"}}," + System.lineSeparator());
                    }
                }
            }  
            labelNames += "],\n";
            // append labels with no bounding box
            labelNames += "\"extra labels\": [";
            for (Label label : labels) {
                List<Instance> instances = label.getInstances(); 
                if (instances.isEmpty()){
                  labelNames += " \"" + label.getName() + "\", ";  
                }
            }  
            labelNames += "]\n}";
            // convert shortened json to stream for uploading
            InputStream stream = new ByteArrayInputStream(labelNames.getBytes(StandardCharsets.UTF_8));
            ObjectMetadata om = new ObjectMetadata();
            om.setContentLength(labelNames.length());
            om.setContentType("json");

            // save full response as a string
            String out = result.toString();
            // convert to input stream for uploading
            InputStream stream2 = new ByteArrayInputStream(out.getBytes(StandardCharsets.UTF_8));
            ObjectMetadata om2 = new ObjectMetadata();
            om2.setContentLength(out.length());
            om2.setContentType("json");

            System.out.println("Writing to: " + srcBucket + "/" + dstKey);

            try {
                s3.putObject(srcBucket, dstKey, stream, om);
                //s3.putObject(srcBucket, dstKey2, stream2, om2);
            }
            catch(AmazonServiceException e)
            {
                System.err.println(e.getErrorMessage());
                System.exit(1);
            }
			
		} catch (AmazonServiceException e) {
			e.printStackTrace();
		}
		return "ok";
    }
}
