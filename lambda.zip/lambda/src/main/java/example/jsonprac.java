import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;

public class jsonprac {

    public static void main(String args[]) throws IOException {
        File fulloutput = new File("fulloutput.json");
        try {
//            fulloutput.createNewFile();
            FileWriter writer = new FileWriter(fulloutput);
            writer.write("This\n is\n an\n example\n"); 
            writer.close();
        }
        catch (IOException e) {
	     e.printStackTrace();
        }
    }
}

    /*        File fulloutput = new File("fulloutput.json");
            try {
                fulloutput.createNewFile();
                FileWriter file = new FileWriter(fulloutput);
                file.write(out, 0, out.length());
                file.close();
            }
            catch (IOException e) {
			    e.printStackTrace();
            }
*/
