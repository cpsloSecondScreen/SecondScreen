package com.example.flingphone;

import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.amazon.whisperplay.fling.media.controller.RemoteMediaPlayer;
import com.amazon.whisperplay.fling.media.controller.DiscoveryController;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class MainActivity extends AppCompatActivity {

    private ListView deviceView;
    private Button refresh;
    private TextView target;
    private String ip;

    DiscoveryController mController;
    RemoteMediaPlayer mCurrentDevice;

    List<RemoteMediaPlayer> mDeviceList = new ArrayList<>();
    String[] deviceNames;


    private DiscoveryController.IDiscoveryListener mDiscovery = new DiscoveryController.IDiscoveryListener() {
        @Override
        public void playerDiscovered(RemoteMediaPlayer player) {
            //add media player to the application’s player list.
            if(!mDeviceList.contains(player)){
                mDeviceList.add(player);
            }
        }
        @Override
        public void playerLost(RemoteMediaPlayer player) {
            //remove media player from the application’s player list.
            if(mDeviceList.contains(player)){
                mDeviceList.remove(player);
            }
        }
        @Override
        public void discoveryFailure() {
           // Toast.makeText(getApplicationContext(), "Discovery Failure", Toast.LENGTH_LONG).show();

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ClientFactory.init(this);
        WifiManager wifiMan = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        WifiInfo wifiInf = wifiMan.getConnectionInfo();
        int ipAddress = wifiInf.getIpAddress();
        ip = String.format("%d.%d.%d.%d", (ipAddress & 0xff),(ipAddress >> 8 & 0xff),(ipAddress >> 16 & 0xff),(ipAddress >> 24 & 0xff));
        setupUI();

    }

    public String getIp() {
        return ip;
    }
    public RemoteMediaPlayer getmCurrentDevice() {
        return mCurrentDevice;
    }

    @Override
    protected void onResume() {
        super.onResume();
        mController.start("com.your.organization.TVPlayer", mDiscovery);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mController.stop();
    }

    private void setupUI(){
        deviceView = findViewById(R.id.deviceList);
        mController = new DiscoveryController(getApplicationContext());
        refresh = findViewById(R.id.refresh);
        target = findViewById(R.id.target);

        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deviceNames = new String[mDeviceList.size()];
                int i = 0;
                for(RemoteMediaPlayer remoteMediaPlayer : mDeviceList){
                    deviceNames[i] = remoteMediaPlayer.getName();
                    i++;
                }
                ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, deviceNames);
                deviceView.setAdapter(adapter);
            }
        });

        deviceView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                mCurrentDevice = mDeviceList.get(position);
                try{
                    //oast.makeText(getApplicationContext(), "ismuted(): " + mCurrentDevice.getName(), Toast.LENGTH_LONG).show();
                    target.setText("connected to " + mCurrentDevice.getUniqueIdentifier());
                    Intent uploadIntent = new Intent(MainActivity.this, UploadActivity.class);
                    MainActivity.this.startActivity(uploadIntent);

                } catch (Exception e){
                    e.printStackTrace();
                }

            }
        });
    }
}
