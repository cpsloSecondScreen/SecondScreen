package com.example.flingphone;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.amazon.whisperplay.fling.media.controller.RemoteMediaPlayer;
import com.amazonaws.mobile.config.AWSConfiguration;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class UploadActivity extends AppCompatActivity {

    private final String TAG = UploadActivity.class.getSimpleName();

    private String photoPath;
    private String storageBucketName;
    private String region;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);

        Button btnTakeScreenshot = findViewById(R.id.btn_take_screenshot);
        btnTakeScreenshot.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                takeScreenshot();
            }
        });
        setStorageInfo();
    }

    private void takeScreenshot(){
        // this seems bad
        // should probably generate ip and current device in separate file from main
        // and access getters in both this file and main
        MainActivity mainObj = new MainActivity();
        String ip = mainObj.getIp();
        RemoteMediaPlayer mCurrentDevice = mainObj.getmCurrentDevice();
        mCurrentDevice.sendCommand(ip).getAsync(new UploadActivity.ErrorResultHandler("send command", "send command failure"));
        new Thread(new Server()).start();
    }

    private class ErrorResultHandler implements RemoteMediaPlayer.FutureListener<Void> {
        private String mCommand;
        private String mMsg;

        ErrorResultHandler(String command, String msg) {
            mCommand = command;
            mMsg = msg;
        }

        @Override
        public void futureIsNow(Future<Void> result) {
            try {
                result.get();
                Log.i("Main", mCommand + ": successful");
            } catch(ExecutionException e) {
                Log.i("main", mMsg);
                e.printStackTrace();
            } catch(Exception e) {
                Log.i("main", mMsg);
                e.printStackTrace();
            }
        }
    }

    private void setStorageInfo() {
        JSONObject s3Config = new AWSConfiguration(this)
                .optJsonObject("S3TransferUtility");
        try {
            storageBucketName = s3Config.getString("Bucket");
            region = s3Config.getString("Region");
        } catch (JSONException e) {
            Log.e(TAG, "Can't find S3 bucket", e);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(UploadActivity.this,
                            "Error: Can't find S3 bucket. \nHave you run 'amplify add storage'? ",
                            Toast.LENGTH_LONG).show();
                }
            });
        }
    }
    // Checks permissions for upload (required)
    private void uploadAndSave() {
        if (photoPath != null) {
            // For higher Android levels, we need to check permission at runtime
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                // Permission is not granted
                Log.d(TAG, "READ_EXTERNAL_STORAGE permission not granted! Requesting...");
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        1);
            }
            // Upload a photo first. We will only call save on its successful callback.
            uploadWithTransferUtility(photoPath);
        }
    }
    private String getS3Key(String localPath) {
        //We have read and write ability under the public folder
        return "public/" + new File(localPath).getName();
    }
    public void uploadWithTransferUtility(String localPath) {
        String key = getS3Key(localPath);

        Log.d(TAG, "Uploading file from " + localPath + " to " + key);

        TransferObserver uploadObserver =
                ClientFactory.transferUtility().upload(
                        key,
                        new File(localPath));

        // Attach a listener to the observer to get state update and progress notifications
        uploadObserver.setTransferListener(new TransferListener() {

            @Override
            public void onStateChanged(int id, TransferState state) {
                if (TransferState.COMPLETED == state) {
                    // Handle a completed upload.
                    Log.d(TAG, "Upload is completed. ");

                    // Don't think I need this
                    // Upload is successful. Save the rest and send the mutation to server.
                    //save();
                }
            }

            @Override
            public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {
                float percentDonef = ((float) bytesCurrent / (float) bytesTotal) * 100;
                int percentDone = (int)percentDonef;

                Log.d(TAG, "ID:" + id + " bytesCurrent: " + bytesCurrent
                        + " bytesTotal: " + bytesTotal + " " + percentDone + "%");
            }

            @Override
            public void onError(int id, Exception ex) {
                // Handle errors
                Log.e(TAG, "Failed to upload photo. ", ex);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(UploadActivity.this, "Failed to upload photo", Toast.LENGTH_LONG).show();
                    }
                });
            }

        });
    }

    class Server implements Runnable{

        @Override
        public void run() {
            try{
                ServerSocket serverSocket = new ServerSocket(8888);
                Socket client = serverSocket.accept();

                byte[] buffer = new byte[1024];
                int read = 0;
                InputStream instream = client.getInputStream();

                Date now = new Date();
                android.text.format.DateFormat.format("yyyy-MM-dd_hh:mm:ss", now);
                // use class variable photoPath so can access elsewhere in file
                photoPath = getExternalFilesDir(Environment.DIRECTORY_PICTURES).toString() + "/" + now + ".jpg";
                FileOutputStream fos = new FileOutputStream(photoPath);

                read = instream.read(buffer);

                while(read > 0){
                    fos.write(buffer, 0, read);
                    read = instream.read(buffer);
                }

                instream.close();
                fos.close();
                //TODO think I want to put this somewhere else
                uploadAndSave();

            } catch (Exception e){
                e.printStackTrace();
            }

        }
    }
}
