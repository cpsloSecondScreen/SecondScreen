package com.example.secondscreentv;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.amazon.whisperplay.fling.media.service.CustomMediaPlayer;
import com.amazon.whisperplay.fling.media.service.CustomMediaPlayer.StatusListener;
import com.amazon.whisperplay.fling.media.service.MediaPlayerHostService;
import com.amazon.whisperplay.fling.media.service.MediaPlayerInfo;
import com.amazon.whisperplay.fling.media.service.MediaPlayerStatus;

import java.io.IOException;

public class TVPlayerService extends MediaPlayerHostService {

    TVPlayer tvPlayer;
    serviceBinder binder;
    Context maincontext;
    StatusListener mStatusListener;

    @Override
    public CustomMediaPlayer createServiceImplementation() {
        //getApplicationContext();
        tvPlayer = new TVPlayer(this);
        if(mStatusListener != null){
            tvPlayer.addStatusListener(mStatusListener);
        }
        return  tvPlayer;
    }

    @Override
    public String getPlayerId() {
        return "com.your.organization.TVPlayer";
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public void onCreate() {
        binder = new serviceBinder();
        super.onCreate();
    }

    private void openMainActivity() {
        Intent mainIntent = new Intent(this, MainActivity.class);
        mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(mainIntent);
    }

    protected class serviceBinder extends Binder implements ServiceControl{

        @Override
        public void setContext(Context context){
            maincontext = context;
        }

        @Override
        public void setActivity(Activity activity) {
            if(tvPlayer != null){
                tvPlayer.setActivity(activity);
            }
        }

        @Override
        public double getVolume() throws IOException {
            return 0;
        }

        @Override
        public void setVolume(double v) throws IOException {

        }

        @Override
        public boolean isMute() throws IOException {
            return false;
        }

        @Override
        public void setMute(boolean b) throws IOException {

        }

        @Override
        public long getPosition() throws IOException {
            return 0;
        }

        @Override
        public long getDuration() throws IOException {
            return 0;
        }

        @Override
        public MediaPlayerStatus getStatus() throws IOException {
            return null;
        }

        @Override
        public boolean isMimeTypeSupported(String s) throws IOException {
            return false;
        }

        @Override
        public void pause() throws IOException {

        }

        @Override
        public void play() throws IOException {

        }

        @Override
        public void stop() throws IOException {

        }

        @Override
        public void seek(PlayerSeekMode playerSeekMode, long l) throws IOException {

        }

        @Override
        public void setMediaSource(String s, String s1, boolean b, boolean b1) throws IOException {

        }

        @Override
        public void setPlayerStyle(String s) {

        }

        @Override
        public void addStatusListener(StatusListener statusListener) {
            if(mStatusListener == null){
                mStatusListener = statusListener;
            }
            if(tvPlayer != null){
                tvPlayer.addStatusListener(statusListener);
            }

        }

        @Override
        public void removeStatusListener(StatusListener statusListener) {
            if(mStatusListener == statusListener){
                mStatusListener = null;
            }

            if(tvPlayer != null){
                tvPlayer.removeStatusListener(statusListener);
            }
        }

        @Override
        public void setPositionUpdateInterval(long l) throws IOException {

        }

        @Override
        public void sendCommand(String s) throws IOException {
            if(tvPlayer != null){
                Log.i("service", "sendCommand: recieved");
                Toast.makeText(maincontext, "command recieved", Toast.LENGTH_LONG).show();
                tvPlayer.sendCommand(s);
            }
        }

        @Override
        public MediaPlayerInfo getMediaInfo() throws IOException {
            return null;
        }
    }
}
