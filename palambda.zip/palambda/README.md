# palambda
lambda function which will request items from Product Advertising API
